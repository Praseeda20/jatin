package com.cg.olg.service;

import java.util.ArrayList;

import com.cg.olg.bean.OnlineGamingBean;
import com.cg.olg.exception.GamingException;

public interface OnlineGamingService {
	ArrayList<OnlineGamingBean> viewAllGames() throws GamingException;
	public OnlineGamingBean bookGame(String gameId)throws GamingException;
	public void showPrice(String gameId)throws GamingException;
}
