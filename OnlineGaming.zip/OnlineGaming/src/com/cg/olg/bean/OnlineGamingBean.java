package com.cg.olg.bean;

public class OnlineGamingBean {
	@Override
	public String toString() {
		return "OnlineGamingBean [gameId=" + gameId + ", gameName=" + gameName
				+ ", price=" + price + ", slot=" + slot + ", status=" + status
				+ "]";
	}

	private String gameId;
	private String gameName;
	private float price;
	private int slot;
	private String status;

	public OnlineGamingBean() {
		super();

	}

	public OnlineGamingBean(String gameId, String gameName, float price, int slot,
			String status) {
		super();
		this.gameId = gameId;
		this.gameName = gameName;
		this.price = price;
		this.slot = slot;
		this.status = status;
	}

	public String getGameId() {
		return gameId;
	}

	public void setGameId(String gameId) {
		this.gameId = gameId;
	}

	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getSlot() {
		return slot;
	}

	public void setSlot(int slot) {
		this.slot = slot;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
