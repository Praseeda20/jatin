package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IBookingDetailsDAO {
	
	String bookHotelRoom(BookingDetailsBean bookingDetailsBean) throws HBMSException;
	
	boolean bookingStatus(String bookingId) throws HBMSException;
	
	BookingDetailsBean getBookingDetail(String bookingId) throws HBMSException;
	
	List<BookingDetailsBean> getBookingDetails(String userId) throws HBMSException;
}
