package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.util.DBConnection;

public class RoomDetailsDAOImpl implements IRoomDetailsDAO {

	@Override
	public boolean checkRoomAvailability(String roomId)
			throws HBMSException {
		
		boolean available = false;
		String availability = null;
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperRoomDetails.CHECK_ROOM_AVAILABITY); // Preparing query
						){
			
			preparedStatement.setString(1, roomId);
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			while(rs.next())
			{
				availability=rs.getString(1);
			}
			if(availability.equalsIgnoreCase("Yes")){
				available = true;
			}
		} catch(SQLException sqlEx){
			throw new HBMSException(sqlEx.getMessage()); //Throws error
		}
		return available;
	}
	
	@Override
	public List<String> getAllRoomIds() throws HBMSException {

		List<String> roomIdList = new ArrayList<String>();
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperRoomDetails.GET_ROOM_IDS); // Preparing query
						){
			
			
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			
			while(rs.next())
			{
				String roomId=rs.getString(1);

				roomIdList.add(roomId);
			}
			
		} catch(SQLException sqlEx){
			throw new HBMSException(sqlEx.getMessage()); //Throws error
		}
		return roomIdList;
	}

	@Override
	public String getRoomRate(String roomId) throws HBMSException {
		
		String roomRate = null;
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperRoomDetails.GET_ROOM_AMOUNT); // Preparing query
						){
			
			preparedStatement.setString(1, roomId);
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			while(rs.next())
			{
				roomRate=rs.getString(1);
			}
		} catch(SQLException sqlEx){
			throw new HBMSException(sqlEx.getMessage()); //Throws error
		}
		
		return roomRate;
	}

	@Override
	public List<RoomDetailsBean> getRoomHotelID() throws HBMSException {
		
		List<RoomDetailsBean> roomHotelIDList = new ArrayList<RoomDetailsBean>();
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperRoomDetails.SHOW_ROOMID_HOTELID); // Preparing query
						){
			
			
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			
			while(rs.next())
			{
				String hotelId = rs.getString(1);
				String roomId=rs.getString(2);
				 
				RoomDetailsBean roomDetailsBean = new RoomDetailsBean(hotelId,roomId);
				roomHotelIDList.add(roomDetailsBean);
			}
			
		} catch(SQLException sqlEx){
			throw new HBMSException(sqlEx.getMessage()); //Throws error
		}
		return roomHotelIDList;
	}
	
	
	@Override
	public RoomDetailsBean getRoomDetail(String roomId) throws HBMSException {
		
		RoomDetailsBean roomDetailsBean = new RoomDetailsBean();
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperRoomDetails.GET_ROOM_DETAIL); // Preparing query
						){
			
			preparedStatement.setString(1, roomId);
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			
			while(rs.next())
			{
				roomDetailsBean.setHotelId(rs.getString(1));
				roomDetailsBean.setRoomId(rs.getString(2));
				roomDetailsBean.setRoomNo(rs.getString(3));
				roomDetailsBean.setRoomType(rs.getString(4));
				roomDetailsBean.setPerNightRate(rs.getDouble(5));
				roomDetailsBean.setAvailability(rs.getString(6));
				roomDetailsBean.setPhoto(null);

			}
			
		} catch(SQLException sqlEx){
			throw new HBMSException(sqlEx.getMessage()); //Throws error
		}
		return roomDetailsBean;
	}
	
	@Override
	public List<RoomDetailsBean> viewRooms(String hotelId) throws HBMSException {
		
		RoomDetailsBean roomDetailsBean = new RoomDetailsBean();
		List<RoomDetailsBean> roomsList = new ArrayList<RoomDetailsBean>();
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperRoomDetails.SHOW_ROOMDETAILS); // Preparing query
						){
			
			preparedStatement.setString(1, hotelId);
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			while(rs.next())
			{
				String hotelID=rs.getString(1);
				String roomId=rs.getString(2);
				String roomNo=rs.getString(3);
				String roomType=rs.getString(4);
				double perNightRate=rs.getDouble(5);
				String availability=rs.getString(6);
				String photo = null;
				/*hotel_id varchar(4),  room_id varchar(4),  room_no varchar(3), 
				room_type varchar(20), per_night_rate number(6,2), 
				availability varchar(3), 
				photo blob*/
				roomDetailsBean = new RoomDetailsBean(hotelID,roomId,roomNo,roomType,perNightRate,availability,photo);
				roomsList.add(roomDetailsBean);
			}
			
		} catch(SQLException sqlEx){
			throw new HBMSException(sqlEx.getMessage()); //Throws error
		}
		return roomsList;
	}
}
