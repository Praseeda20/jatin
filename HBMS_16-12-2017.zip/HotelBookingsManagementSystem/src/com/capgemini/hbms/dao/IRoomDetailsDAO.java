package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IRoomDetailsDAO {

	boolean checkRoomAvailability(String roomId) throws HBMSException;
	
	List<String> getAllRoomIds() throws HBMSException;
	
	String getRoomRate(String roomId) throws HBMSException;
	
	List<RoomDetailsBean> getRoomHotelID() throws HBMSException;

	RoomDetailsBean getRoomDetail(String roomId) throws HBMSException;
	
	List<RoomDetailsBean> viewRooms(String hotelId) throws HBMSException;
}
