package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.util.DBConnection;

public class BookingDetailsDAOImpl implements IBookingDetailsDAO {

	BookingDetailsBean bookingDetailsBean = new BookingDetailsBean();
	RoomDetailsBean roomDetailsBean = new RoomDetailsBean();
	
	@Override
	public String bookHotelRoom(BookingDetailsBean bookingDetailsBean)
			throws HBMSException {
		
		String bookingId = null;
		int records = 0;
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperBookingDetails.INSERT_BOOKING_DETAILS); // Preparing query
						){
			java.sql.Date sbookFrom = java.sql.Date.valueOf(bookingDetailsBean.getBookedFrom());
			java.sql.Date sbookTo = java.sql.Date.valueOf(bookingDetailsBean.getBookedTo());
			//Giving values to query  statement
			preparedStatement.setString(1, bookingDetailsBean.getRoomId());
			preparedStatement.setString(2, bookingDetailsBean.getUserId());
			preparedStatement.setDate(3, sbookFrom);
			preparedStatement.setDate(4, sbookTo);
			preparedStatement.setInt(5, bookingDetailsBean.getNoOfAdults());
			preparedStatement.setInt(6, bookingDetailsBean.getNoOfChildren());
			preparedStatement.setDouble(7, bookingDetailsBean.getAmount());

			
			records = preparedStatement.executeUpdate(); //Executing the query
			
			if(records>0){	 //Checking for the record retrieval
				PreparedStatement preparePatientID = 
						connPatient.prepareStatement(QueryMapperBookingDetails.SHOW_BOOKINGID); //Preparing query
				
				ResultSet bookingIdRecord = preparePatientID.executeQuery(); //Execute query
				
				if(bookingIdRecord.next()){
					bookingId = bookingIdRecord.getString(1); 
				}
			}
			else
			{
				throw new HBMSException();
			}
			
			
		} catch(SQLException sqlEx){
			throw new HBMSException(sqlEx.getMessage()); //Throws error
		}
		
	return bookingId;
		
	}

	@Override
	public boolean bookingStatus(String bookingId) throws HBMSException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public BookingDetailsBean getBookingDetail(String bookingId) throws HBMSException {
		
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperBookingDetails.GET_BOOKING_DETAIL); // Preparing query
						){
			
			preparedStatement.setString(1, bookingId);
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			
			while(rs.next())
			{
				bookingDetailsBean.setBookingId(rs.getString(1));
				bookingDetailsBean.setRoomId(rs.getString(2));
				bookingDetailsBean.setUserId(rs.getString(3));
				bookingDetailsBean.setBookedFrom(rs.getDate(4).toLocalDate());
				bookingDetailsBean.setBookedTo(rs.getDate(5).toLocalDate());
				bookingDetailsBean.setNoOfAdults(rs.getInt(6));
				bookingDetailsBean.setNoOfChildren(rs.getInt(7));
				bookingDetailsBean.setAmount(rs.getDouble(8));
			}
			/*(booking_id varchar(4), room_id varchar(4),  user_id varchar(4), 
					booked_from date, booked_to date, 
					no_of_adults number(6,2), no_of_children number(6,2), amount number(6,2));*/
			
		} catch(SQLException sqlEx){
			throw new HBMSException(sqlEx.getMessage()); //Throws error
		}
		return bookingDetailsBean;
	}

	@Override
	public List<BookingDetailsBean> getBookingDetails(String userId)
			throws HBMSException {

		List<BookingDetailsBean> bookingList = new ArrayList<BookingDetailsBean>();
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperBookingDetails.GET_BOOKING_DETAILS); // Preparing query
						){
			
			preparedStatement.setString(1, userId);
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			
			while(rs.next())
			{
				bookingDetailsBean.setBookingId(rs.getString(1));
				bookingDetailsBean.setRoomId(rs.getString(2));
				bookingDetailsBean.setUserId(rs.getString(3));
				bookingDetailsBean.setBookedFrom(rs.getDate(4).toLocalDate());
				bookingDetailsBean.setBookedTo(rs.getDate(5).toLocalDate());
				bookingDetailsBean.setNoOfAdults(rs.getInt(6));
				bookingDetailsBean.setNoOfChildren(rs.getInt(7));
				bookingDetailsBean.setAmount(rs.getDouble(8));
				
				bookingList.add(bookingDetailsBean);
			}
			/*(booking_id varchar(4), room_id varchar(4),  user_id varchar(4), 
					booked_from date, booked_to date, 
					no_of_adults number(6,2), no_of_children number(6,2), amount number(6,2));*/
			
		} catch(SQLException sqlEx){
			throw new HBMSException(sqlEx.getMessage()); //Throws error
		}
		return bookingList;
	}

	
	

}
