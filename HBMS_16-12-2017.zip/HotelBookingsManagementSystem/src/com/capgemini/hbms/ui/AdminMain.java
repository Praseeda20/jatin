package com.capgemini.hbms.ui;

import java.util.Scanner;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.BookingServiceImpl;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IBookingService;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.IUserService;
import com.capgemini.hbms.service.RoomServiceImpl;
import com.capgemini.hbms.service.UserServiceImpl;

public class AdminMain {

	public void main() {

		String userId;
		String password;
		
		String hotelId;
		String hotelName;
		String address;
		String city;
		String description;
		Double avgRatePerNight;
		String phoneNo1;
		String phoneNo2;
		String rating;
		String email;
		String fax;
		
		String role;
		boolean valid = false;
		int result = 0;
		
		Scanner scInput = new Scanner(System.in);

		role = "Admin";
		
		UserDetailsBean userDetailsBean = new UserDetailsBean();
		IUserService userService = new UserServiceImpl();
		IHotelService hotelService = new HotelServiceImpl();
		IBookingService bookingService = new BookingServiceImpl();
		IRoomService roomService = new RoomServiceImpl();
		HbmsMain hbms = new HbmsMain();

		System.out.println("------------------\nADMIN\n------------------\n\n");

		System.out.println("1.Login");
		System.out.println("2.Exit\n\n");

		String choiceAdmin;

		choiceAdmin = scInput.nextLine();

		switch (choiceAdmin) {

		case "1":
			System.out
					.println("\n\n-----------------\nADMIN LOGIN\n-----------------\n\n");
			System.out.print("Enter the UserID   : ");
			userId = scInput.nextLine();
			System.out.print("Enter the Password : ");
			password = scInput.nextLine();
			userDetailsBean = new UserDetailsBean(userId, password, role);
			try {
				valid = userService.LoginCheck(userDetailsBean);
				if (valid) {
					System.out.println("\n\nSuccessfully Logined!!\n\n");

					String choice;
					System.out
					.println("\n\n-----------------\nADMIN\n-----------------\n\n");
					System.out
							.println("1.Hotel Management\n2.Room Management\n3.Reports\n\n");
					choice = scInput.nextLine();

					switch (choice) {
						
						case "1" :
						
							
							System.out
							.println("\n\n-----------------\nHOTEL MANAGEMENT\n-----------------\n\n");
							System.out
							.println("1.Add Hotel\n2.Delete Hotel\n3.Modify Hotel\n\n");
							
							String choiceHotelManagement = scInput.nextLine();
							
							switch(choiceHotelManagement){
								case "1" :

									boolean isInserted = hbms.addHotel();
									
									break;
									
								case "2" :
									
									boolean isDeleted = false;
									result = 0;
									while(!isDeleted){
											
										
										System.out
										.println("\n\n--------------\nDELETE HOTEL\n--------------\n\n");
										
										System.out.print("Enter Hotel Id : ");
										hotelId = scInput.nextLine();
										
										
										
										result = hbms.deleteHotel(hotelId);
										
										if(result==1){
											isDeleted = true;
											System.out.println("\n\nHotel Detail successfully deleted\n\n");
										}else if(result==2){
											isDeleted = true;
											System.out.println("\n\nCancelled Deletion process!!\n\n");
										}
									}
									break;
									
								case "3" :
									System.out
									.println("\n\n--------------\nMODIFY HOTEL\n--------------\n\n");
									result = 0;
									while(result == 0){

										System.out.print("Enter Hotel Id : ");
										hotelId = scInput.nextLine();
										
										result = hbms.updateHotel(hotelId);

									}
									break;
							}	
							break;
							
						case "2" : 
							
							break;
							
						case "3" :
							
							break;
							
						default:
							
							break;
					}
				}
			} catch (HBMSException e) {

				System.out.println(e.getMessage());
			}
			break;

		case "2":
			break;
		default:

			System.out.println("\n\nPlease select a valid option\n\n");
			break;

		}
	}
}
