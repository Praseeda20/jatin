package com.capgemini.hbms.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.BookingServiceImpl;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IBookingService;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.IUserService;
import com.capgemini.hbms.service.RoomServiceImpl;
import com.capgemini.hbms.service.UserServiceImpl;

public class HbmsMain {
	
	private String password;
	private String userName;
	private String mobileNo;
	private String phone;
	private String address;
	private String email;
	
	private String bookingId;
	private LocalDate bookedFrom;
	private LocalDate bookedTo;
	private int noOfAdults;
	private int noOfChildren;
	private double amount;
	
	private String hotelName;
	private String city;
	private String description;
	private Double avgRatePerNight;
	private String phoneNo1;
	private String phoneNo2;
	private String rating;
	private String fax;

	UserDetailsBean userDetailsBean = new UserDetailsBean();
	HotelDetailsBean hotelDetailsBean = new HotelDetailsBean();
	BookingDetailsBean bookingDetailsBean = new BookingDetailsBean();
	
	IHotelService hotelService = new HotelServiceImpl();
	IUserService userService = new UserServiceImpl();
	IRoomService roomService = new RoomServiceImpl();
	IBookingService bookingService = new BookingServiceImpl();
	
	public static void main(String[] args) {
		
		String role;
		boolean valid = false;
		String choiceHBMS;
		
		Scanner scInput = new Scanner(System.in);
		
		while(true){
			
			System.out.println("------------------------\n\nHOTEL MANAGEMENT SYSTEM\n\n------------------------");
			System.out.println("\n\n\n1.Admin\n2.Employee\n3.Customer\n\n");
			
			choiceHBMS = scInput.nextLine();
			
			//CHOICE of ADMIN, EMPLOYEE, CUSTOMER
			switch(choiceHBMS){
			
				case "1" :
//==============================================ADMIN==============================================================					
							AdminMain adminMain = new AdminMain();
							adminMain.main();
							break;
//==============================================EOF ADMIN===================================================================					
				case "2" : 
//==============================================EMPLOYEE===========================================================
							EmployeeMain employeeMain = new EmployeeMain();
							employeeMain.main();
							break;
//==============================================EOF EMPLOYEE===================================================================							
				case "3" :
//==============================================CUSTOMER===========================================================
							CustomerMain customerMain = new CustomerMain();
							customerMain.main();
							break;
//===================================================EOF CUSTOMER==============================================================			
							
				default : 
							System.out.println("Entered choice is incorrect. Please select a valid number!!\n\n");
							break;
			
			
			}
			
			
			
		}

	}
	
	public Object Register(String role){
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter UserName : ");
		userName = scInput.nextLine();
		System.out.print("Enter Password : ");
		password = scInput.nextLine();
		System.out.print("Enter Mobile Number : ");
		mobileNo = scInput.nextLine();
		System.out.print("Enter Phone Number : ");
		phone = scInput.nextLine();
		System.out.print("Enter Address : ");
		address = scInput.nextLine();
		System.out.print("Enter Email : ");
		email = scInput.nextLine();
		
		userDetailsBean = new UserDetailsBean(userName,password,role,mobileNo,phone,address,email);
		return userDetailsBean;
	}
	
	public String Book(String roomId,String userId) throws HBMSException{
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.println("\n-----------------------\nEnter Booking Details\n-----------------------\n\n");
		System.out.print("From Date (dd/MM/yyyy)    : ");
		String bookF = scInput.nextLine();
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		TemporalAccessor ta1 = dtf.parse(bookF);
		LocalDate bookFrom = LocalDate.from(ta1);

		System.out.print("To Date (dd/MM/yyyy)      : ");
		String bookT = scInput.nextLine();
		
		TemporalAccessor ta2 = dtf.parse(bookT);
		LocalDate bookTo = LocalDate.from(ta2);
		
		
		System.out.print("Enter the no. of adults   : ");
		noOfAdults = scInput.nextInt();
		scInput.nextLine();
		
		System.out.print("Enter the no. of children : ");
		noOfChildren = scInput.nextInt();
		scInput.nextLine();
		
		long daysBetween = ChronoUnit.DAYS.between(bookFrom, bookTo);
		
		String ratePerNight = roomService.getRoomRate(roomId);
		int rate = Integer.parseInt(ratePerNight);
		
		amount = daysBetween * rate;
		
		
		bookingDetailsBean.setUserId(userId);
		bookingDetailsBean.setRoomId(roomId);
		bookingDetailsBean.setBookedFrom(bookFrom);
		bookingDetailsBean.setBookedTo(bookTo);
		bookingDetailsBean.setNoOfAdults(noOfAdults);
		bookingDetailsBean.setNoOfChildren(noOfChildren);
		bookingDetailsBean.setAmount(amount);
		
		bookingId = bookingService.bookHotelRoom(bookingDetailsBean);
		
		System.out.println("\n\nHotel Booked Successfully!!!!\n\nYour Booking Id is " + bookingId + "\n");
		
		return bookingId;
	}
	
	
	
	public int HotelSearch(String city){
		int index = 0;
		try {
			List<HotelDetailsBean> hotelsList = hotelService.viewHotels(city);
			
			if(hotelsList.isEmpty()){
				;
			}else{
				
				
				System.out.println("\n\nHotels List\n");
				
				System.out.println("Hotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");
				
				for(HotelDetailsBean hotel : hotelsList){
					
					++index;
					System.out.println(hotel.getHotelId() + "           " + hotel.getCity() + "     " + hotel.getHotelname() + "      " + hotel.getAddress() + "      " + hotel.getDescription() + "              " + hotel.getAvgRatePerNight() + "             " + hotel.getPhoneNo1() + "      " + hotel.getPhoneNo2() + "      " + hotel.getRating() + "      " + hotel.getEmail() + "      " + hotel.getFax());
				}
				
				System.out.println("\nTotal Hotels found : " + index + "\n\n");
			}
		} catch (HBMSException e) {
			System.out.println("\nDue to some reason Hotel lists are not available");
			e.printStackTrace();
		}
		return index;
	}
	
	public boolean viewHotelRooms(String hotelId,String city){
		
		boolean found = false;
		boolean hotelInCity = false;
		try {
			List<RoomDetailsBean> roomDetails = roomService.viewRooms(hotelId);
			
			if(roomDetails.isEmpty()){
				;
			}else{
				
				HotelDetailsBean hotelDetailsBean = hotelService.viewHotel(hotelId);
				
				if(hotelDetailsBean.getCity().equalsIgnoreCase(city)){
					System.out.println("\n\nRoom details for Hotel ID : " + hotelId);
					
					System.out.println("Hotel ID       Room ID         Room No      Room Type     Per Night Rate      Availability\n");
					for(RoomDetailsBean roomDetail : roomDetails){
						
						if(roomDetail.getRoomType().equals("AC")){
							System.out.println(roomDetail.getHotelId() + "             " + roomDetail.getRoomId() + "            " + roomDetail.getRoomNo() + "             " + roomDetail.getRoomType() + "               " + roomDetail.getPerNightRate() + "             " + roomDetail.getAvailability());
						}else{
							System.out.println(roomDetail.getHotelId() + "             " + roomDetail.getRoomId() + "            " + roomDetail.getRoomNo() + "             " + roomDetail.getRoomType() + "           " + roomDetail.getPerNightRate() + "             " + roomDetail.getAvailability());
						}
						
					}
					found = true;
				}
			}
			
		} catch (HBMSException e) {
			System.out.println("No rooms available");
			e.printStackTrace();
		}
		return found;
	}
	
	public List<String> viewCities(){
		
		List<HotelDetailsBean> listOfHotels;
		List<String> repeatedCities = new ArrayList<String>();
		List<String> cities = new ArrayList<String>();
		int flag = 1;
		try {
			listOfHotels = hotelService.viewHotels();

			for(HotelDetailsBean hotel : listOfHotels){
				repeatedCities.add(hotel.getCity());
				}

			for(String city : repeatedCities){

				if(cities.isEmpty()){
					cities.add(city);
				}
				else{
					
					for(String cityCheck : cities){
						
						if(city.matches(cityCheck)){
							flag=0;
						}	
					}
					if(flag==1){
						cities.add(city);
					}
					flag = 1;
				}
			}
		} catch (HBMSException e) {
			System.out.println("Cities couldnt be retrived");
			e.printStackTrace();
		}
			
		return cities;
	}
	
	public boolean addHotel() throws HBMSException{
		
		boolean isInserted = false;
		Scanner scInput = new Scanner(System.in);
		
		System.out
		.println("\n\n-----------------\nADD HOTEL\n-----------------\n\n");
		System.out
		.print("Enter Hotel Name                   : ");
		hotelName = scInput.nextLine();
		System.out
		.print("Enter Hotel City                   : ");
		city = scInput.nextLine();
		System.out
		.print("Enter Hotel Address                : ");
		address = scInput.nextLine();
		System.out
		.print("Enter Hotel Description            : ");
		description = scInput.nextLine();
		System.out
		.print("Enter Hotel Average Rate Per Night : ");
		avgRatePerNight = scInput.nextDouble();
		scInput.nextLine();
		System.out
		.print("Enter Hotel Rating                 : ");
		rating = scInput.nextLine();
		System.out
		.print("Enter Hotel Phone Number (1)       : ");
		phoneNo1 = scInput.nextLine();
		System.out
		.print("Enter Hotel Phone Number (2)       : ");
		phoneNo2 = scInput.nextLine();
		System.out
		.print("Enter Hotel Email ID               : ");
		email = scInput.nextLine();
		System.out
		.print("Enter Hotel Fax number             : ");
		fax = scInput.nextLine();
		
		HotelDetailsBean hotelDetailsBean = new HotelDetailsBean(city,hotelName,address,description,avgRatePerNight,phoneNo1,phoneNo2,rating,email,fax);
		
		
		
		try {
			int hotelId = hotelService.insertHotel(hotelDetailsBean);
			
			isInserted = true;
			System.out.println("\nYou have successfully added a new Hotel!!!\n\n");
			
			System.out.println("Hotel Details\n");
			System.out
			.println("Hotel ID               : " + hotelId);
			System.out
			.println("Hotel Name             : " + hotelDetailsBean.getHotelname());
			System.out
			.println("City                   : " + hotelDetailsBean.getCity());
			System.out
			.println("Address                : " + hotelDetailsBean.getAddress());
			System.out
			.println("Description            : " + hotelDetailsBean.getDescription());
			System.out
			.println("Average Rate Per Night : " + hotelDetailsBean.getAvgRatePerNight());
			System.out
			.println("Rating                 : " + hotelDetailsBean.getRating());
			System.out
			.println("Phone Number (1)       : " + hotelDetailsBean.getPhoneNo1());
			System.out
			.println("Phone Number (2)       : " + hotelDetailsBean.getPhoneNo2());
			System.out
			.println("Email ID               : " + hotelDetailsBean.getEmail());
			System.out
			.println("Fax number             : " + hotelDetailsBean.getFax());
			
			
		} catch (Exception e) {
			throw new HBMSException("Sorry !! Hotel couldn't be added \n" + e.getMessage());
		}
		
		
		return isInserted;
	}
	
	
	public int deleteHotel(String hotelId){
		
		int result = 0;
		Scanner scInput = new Scanner(System.in);
		boolean isDeleted = false;
		try {
			HotelDetailsBean hotelDetailsBean = hotelService.viewHotel(hotelId);
			
			if(hotelDetailsBean!=null){
				while(!isDeleted){
					System.out.println("\n\n");
					System.out.println("Hotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");
					
					System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity() + "     " + hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress() + "      " + hotelDetailsBean.getDescription() + "              " + hotelDetailsBean.getAvgRatePerNight() + "             " + hotelDetailsBean.getPhoneNo1() + "      " + hotelDetailsBean.getPhoneNo2() + "      " + hotelDetailsBean.getRating() + "      " + hotelDetailsBean.getEmail() + "      " + hotelDetailsBean.getFax());
				
					System.out.println("\n\n1. Delete Hotel Details");
					System.out.println("2. Cancel\n\n");
					System.out.print("Enter : ");
					String delete = scInput.nextLine();
					
					switch(delete){
						case "1" :
							
							isDeleted = hotelService.deleteHotel(hotelId);
							result = 1;
							break;
							
						case "2" :
							result = 2;
							isDeleted = true;
							break;
					
						default:
							System.out.println("Enter a valid option");
							break;
					}
				}
			}else{
				System.out.println("\nHotel record with hotel id " + hotelId + " not found!!\n\n");
			}
		} catch (HBMSException e) {
			System.out.println("Hotel not found!!"+e.getMessage());
		}
		return result;
	}
	
	public int updateHotel(String hotelId){
		
		int result = 0;
		Scanner scInput = new Scanner(System.in);
		boolean isUpdated = false;
		try {
			HotelDetailsBean hotelDetailsBean = hotelService.viewHotel(hotelId);
			
			if(hotelDetailsBean!=null){
				while(!isUpdated){
					result = 1;
					System.out.println("\n\n");
					System.out.println("Hotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");
					
					System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity() + "     " + hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress() + "      " + hotelDetailsBean.getDescription() + "              " + hotelDetailsBean.getAvgRatePerNight() + "             " + hotelDetailsBean.getPhoneNo1() + "      " + hotelDetailsBean.getPhoneNo2() + "      " + hotelDetailsBean.getRating() + "      " + hotelDetailsBean.getEmail() + "      " + hotelDetailsBean.getFax());
				
					System.out.println("\n\nModify\n");
					System.out.println("1. Hotel Name");
					System.out.println("2. City");
					System.out.println("3. Address");
					System.out.println("4. Description");
					System.out.println("5. Average Rate Per Night");
					System.out.println("6. PhoneNo 1");
					System.out.println("7. PhoneNo 2");
					System.out.println("8. Rating");
					System.out.println("9. Email");
					System.out.println("10. Fax");
					System.out.println("\n11. Modify All Data\n\n");
					System.out.print("Enter : ");
					String update = scInput.nextLine();
					
					switch(update){
						case "1" :
							System.out.println("\n\n------------------------------------------\nModify Hotel Name of hotel '" + hotelDetailsBean.getHotelname() +"'\n------------------------------------------\n\n");
							System.out.print("Enter new Hotel Name : ");
							hotelName = scInput.nextLine();
							
							hotelDetailsBean.setHotelname(hotelName);
							
							isUpdated = hotelService.modifyHotel(hotelDetailsBean);
							
							break;
							
						case "2" :
							
							System.out.println("\n\n------------------------------------------\nModify City of hotel '" + hotelDetailsBean.getHotelname() +"'\n------------------------------------------\n\n");
							System.out.print("Enter new City : ");
							city = scInput.nextLine();
							
							hotelDetailsBean.setCity(city);
							
							isUpdated = hotelService.modifyHotel(hotelDetailsBean);
							
							break;
					
						case "3" :
							
							System.out.println("\n\n------------------------------------------\nModify Address of hotel '" + hotelDetailsBean.getHotelname() +"'\n------------------------------------------\n\n");
							System.out.print("Enter new Address : ");
							address = scInput.nextLine();
							
							hotelDetailsBean.setAddress(address);
							
							isUpdated = hotelService.modifyHotel(hotelDetailsBean);
							
							break;
							
						case "4" :
							
							System.out.println("\n\n------------------------------------------\nModify Description of hotel '" + hotelDetailsBean.getHotelname() +"'\n------------------------------------------\n\n");
							System.out.print("Enter new Description : ");
							description = scInput.nextLine();
							
							hotelDetailsBean.setDescription(description);
							
							isUpdated = hotelService.modifyHotel(hotelDetailsBean);
							
							break;
							
						case "5" :
							
							System.out.println("\n\n------------------------------------------\nModify Average Rate Per Night of hotel '" + hotelDetailsBean.getHotelname() +"'\n------------------------------------------\n\n");
							System.out.print("Enter new Average Rate Per Night : ");
							avgRatePerNight = scInput.nextDouble();
							scInput.nextLine();
							
							hotelDetailsBean.setAvgRatePerNight(avgRatePerNight);
							
							isUpdated = hotelService.modifyHotel(hotelDetailsBean);
							
							break;
							
						case "6" :
							
							System.out.println("\n\n------------------------------------------\nModify Phone Number(1) of hotel '" + hotelDetailsBean.getHotelname() +"'\n------------------------------------------\n\n");
							
							System.out.print("Enter new Phone Number (1) : ");
							phoneNo1 = scInput.nextLine();

							hotelDetailsBean.setPhoneNo1(phoneNo1);
							
							isUpdated = hotelService.modifyHotel(hotelDetailsBean);
							
							break;	
							
						case "7" :
							
							System.out.println("\n\n------------------------------------------\nModify Phone Number(1) of hotel '" + hotelDetailsBean.getHotelname() +"'\n------------------------------------------\n\n");
							
							System.out.print("Enter new Phone Number (2) : ");
							phoneNo2 = scInput.nextLine();

							hotelDetailsBean.setPhoneNo2(phoneNo2);
							
							isUpdated = hotelService.modifyHotel(hotelDetailsBean);
							
							break;	
							
							
						case "8" :
							
							System.out.println("\n\n------------------------------------------\nModify Rating of hotel '" + hotelDetailsBean.getHotelname() +"'\n------------------------------------------\n\n");
							
							System.out.print("Enter new Rating : ");
							rating = scInput.nextLine();

							hotelDetailsBean.setRating(rating);
							
							isUpdated = hotelService.modifyHotel(hotelDetailsBean);
							
							break;	
							
							
						case "9" :
							
							System.out.println("\n\n------------------------------------------\nModify Email of hotel '" + hotelDetailsBean.getHotelname() +"'\n------------------------------------------\n\n");
							
							System.out.print("Enter new Email : ");
							email = scInput.nextLine();

							hotelDetailsBean.setEmail(email);
							
							isUpdated = hotelService.modifyHotel(hotelDetailsBean);
							
							break;	

						case "10" :
							
							System.out.println("\n\n------------------------------------------\nModify Fax of hotel '" + hotelDetailsBean.getHotelname() +"'\n------------------------------------------\n\n");
							
							System.out.print("Enter new Fax : ");
							fax = scInput.nextLine();

							hotelDetailsBean.setFax(fax);
							
							isUpdated = hotelService.modifyHotel(hotelDetailsBean);
							
							break;
							
						case "11" :
							
							System.out.println("\n\n------------------------------------------\nModify all fields of hotel '" + hotelDetailsBean.getHotelname() +"' with hotel ID '" + hotelDetailsBean.getHotelId() + "'\n------------------------------------------\n\n");
							
							System.out.print("Enter new Hotel Name : ");
							hotelName = scInput.nextLine();
							
							System.out.print("Enter new Address : ");
							address = scInput.nextLine();
							
							System.out.print("Enter new City : ");
							city = scInput.nextLine();
							
							System.out.print("Enter new Description : ");
							description = scInput.nextLine();
							
							System.out.print("Enter new Average Rate Per Night : ");
							avgRatePerNight = scInput.nextDouble();
							scInput.nextLine();
							
							System.out.print("Enter new Phone Number (1) : ");
							phoneNo1 = scInput.nextLine();
							
							System.out.print("Enter new Phone Number (2) : ");
							phoneNo2 = scInput.nextLine();
							
							System.out.print("Enter new Rating : ");
							rating = scInput.nextLine();
							
							System.out.print("Enter new Email : ");
							email = scInput.nextLine();
							
							System.out.print("Enter new Fax : ");
							fax = scInput.nextLine();
							
							HotelDetailsBean newHotelDetailsBean = new HotelDetailsBean(city,hotelName,address,description,avgRatePerNight,phoneNo1,phoneNo2,rating,email,fax);
							
							isUpdated = hotelService.modifyHotel(newHotelDetailsBean);
							
							break;
							
						default:
							
							System.out.println("\n\nPlease enter a valid option !!\n\n");
							break;
					}
				}
				
				System.out.println("\nUpdated Hotel Details\n");
				System.out.println("Hotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");
				System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity() + "     " + hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress() + "      " + hotelDetailsBean.getDescription() + "              " + hotelDetailsBean.getAvgRatePerNight() + "             " + hotelDetailsBean.getPhoneNo1() + "      " + hotelDetailsBean.getPhoneNo2() + "      " + hotelDetailsBean.getRating() + "      " + hotelDetailsBean.getEmail() + "      " + hotelDetailsBean.getFax() + "\n\n");
			
			}else{
				System.out.println("\nHotel record with hotel id " + hotelId + " not found!!\n\n");
			}
		} catch (HBMSException e) {
			System.out.println("Hotel not found!!"+e.getMessage());
		}
		
		
		return result;
	}
	
}
