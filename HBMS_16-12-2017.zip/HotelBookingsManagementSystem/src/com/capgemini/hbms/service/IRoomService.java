package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IRoomService {

	RoomDetailsBean getRoomDetail(String roomId) throws HBMSException;
	
	boolean checkRoomAvailability(String roomId) throws HBMSException;
	
	boolean isRoomIdValid(String roomId, String hotelId) throws HBMSException;
	
	public String getRoomRate(String roomId) throws HBMSException;
	
	List<RoomDetailsBean> viewRooms(String hotelId) throws HBMSException;
}
