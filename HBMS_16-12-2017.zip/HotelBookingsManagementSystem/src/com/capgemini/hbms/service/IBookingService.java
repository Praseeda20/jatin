package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IBookingService {

	BookingDetailsBean getBookingDetail(String bookingId) throws HBMSException;
	
	String bookHotelRoom(BookingDetailsBean bookingDetailsBean) throws HBMSException;
	
	boolean bookingStatus(String bookingId) throws HBMSException;
	
	List<BookingDetailsBean> getBookingDetails(String userId) throws HBMSException;
}
