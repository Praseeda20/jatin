package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.dao.BookingDetailsDAOImpl;
import com.capgemini.hbms.dao.IBookingDetailsDAO;
import com.capgemini.hbms.dao.IUserDetailsDAO;
import com.capgemini.hbms.dao.UserDetailsDAOImpl;
import com.capgemini.hbms.exception.HBMSException;

public class UserServiceImpl implements IUserService {

	IUserDetailsDAO userDetailsDao = new UserDetailsDAOImpl();
	IBookingDetailsDAO bookDetailDao = new BookingDetailsDAOImpl();
	
	@Override
	public int RegisterUser(UserDetailsBean userDetails)
			throws HBMSException {
		
		return userDetailsDao.RegisterUser(userDetails);
	}

	@Override
	public boolean LoginCheck(UserDetailsBean userDetails)
			throws HBMSException {
		
		boolean validUser = false;
		List<UserDetailsBean> userCredentialsLists = userDetailsDao.getUserCredentials();
		
		for(UserDetailsBean userCredentialsList : userCredentialsLists){
			if(userCredentialsList.getUserId().equals(userDetails.getUserId())&&userCredentialsList.getPassword().equals(userDetails.getPassword())&&userCredentialsList.getRole().equals(userDetails.getRole())){
				validUser = true;
				break;
			}
		}
		return validUser;
	}

	@Override
	public UserDetailsBean getUserDetails(String userId) throws HBMSException {
		
		return userDetailsDao.getUserDetails(userId);
	}

}
