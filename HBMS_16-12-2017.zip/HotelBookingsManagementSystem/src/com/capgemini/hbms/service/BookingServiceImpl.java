package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.dao.BookingDetailsDAOImpl;
import com.capgemini.hbms.dao.IBookingDetailsDAO;
import com.capgemini.hbms.exception.HBMSException;

public class BookingServiceImpl implements IBookingService {

	IBookingDetailsDAO bookingDetailsDao = new BookingDetailsDAOImpl();
	
	@Override
	public BookingDetailsBean getBookingDetail(String bookingId) throws HBMSException {
		
		return bookingDetailsDao.getBookingDetail(bookingId);
	}

	@Override
	public boolean bookingStatus(String bookingId) throws HBMSException {
		// TODO Auto-generated method stub
		return false;
	}

	
	@Override
	public String bookHotelRoom(BookingDetailsBean bookingDetailsBean)
			throws HBMSException {
	
		return bookingDetailsDao.bookHotelRoom(bookingDetailsBean);
	}

	@Override
	public List<BookingDetailsBean> getBookingDetails(String userId)
			throws HBMSException {
		
		return bookingDetailsDao.getBookingDetails(userId);
	}
}
