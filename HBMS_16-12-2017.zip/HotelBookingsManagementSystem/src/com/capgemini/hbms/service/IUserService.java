package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IUserService {

	int RegisterUser(UserDetailsBean userDetails) throws HBMSException;
	
	boolean LoginCheck(UserDetailsBean userDetails) throws HBMSException;

	public UserDetailsBean getUserDetails(String userId)
			throws HBMSException;
}
/*
register(insert into users)
loginsearch(credentials)
search(hotel)
insert(bookingdetails)
view/check(bookking id)*/