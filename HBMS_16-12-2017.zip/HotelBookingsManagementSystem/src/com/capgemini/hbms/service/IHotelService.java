package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IHotelService {

	public List<HotelDetailsBean> viewHotels(String city) throws HBMSException;

	HotelDetailsBean viewHotel(String hotelId) throws HBMSException;

	List<HotelDetailsBean> viewHotels() throws HBMSException;
	
	int insertHotel(HotelDetailsBean hotelDetailsBean) throws HBMSException;
	
	boolean deleteHotel(String hotelId) throws HBMSException;
	
	boolean modifyHotel(HotelDetailsBean hotelDetailsBean) throws HBMSException;
}
