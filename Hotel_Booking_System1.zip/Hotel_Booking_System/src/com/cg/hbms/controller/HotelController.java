package com.cg.hbms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.hbms.service.HotelService;
import com.cg.hbms.service.HotelServiceImpl;

/**
 * Servlet implementation class HotelController
 */
@WebServlet({ "/LoginPage", "/Login", "/Register", "/RegisterSuccess",
		"/ForwardAdmin","/HotelMgmnt" })
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public HotelController() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String url = request.getServletPath();
		// String target = "";
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		HotelService hotelService = new HotelServiceImpl();
		switch (url) {
		case "/LoginPage":
			dispatcher = request.getRequestDispatcher("jspPages/login.jsp");
			dispatcher.forward(request, response);

		case "/Login":
			dispatcher = request.getRequestDispatcher("jspPages/mainPage.jsp");
			dispatcher.forward(request, response);

		case "/Register":
			dispatcher = request.getRequestDispatcher("jspPages/register.jsp");
			dispatcher.forward(request, response);

		case "/RegisterSuccess":
			dispatcher = request
					.getRequestDispatcher("jspPages/RegisterSuccess.jsp");
			dispatcher.forward(request, response);

		case "/ForwardAdmin":
			String name = request.getParameter("hotelMgmnt");
			System.out.println(name);
			if (name != null && "HOTEL MANAGEMENT".equals(name)) {
				dispatcher = request
						.getRequestDispatcher("jspPages/HotelManagement.jsp");
				dispatcher.forward(request, response);
			}

			if (name != null && "ROOM MANAGEMENT".equals(name)) {
				dispatcher = request
						.getRequestDispatcher("jspPages/RoomManagement.jsp");
				dispatcher.forward(request, response);
			}

			if (name != null && "GENERATE REPORTS".equals(name)) {
				dispatcher = request
						.getRequestDispatcher("jspPages/GenerateReports.jsp");
				dispatcher.forward(request, response);
			}
		case "/HotelMgmnt":
			String param = request.getParameter("addHotel");
			
			dispatcher = request.getRequestDispatcher("jspPages/mainPage.jsp");
			dispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
