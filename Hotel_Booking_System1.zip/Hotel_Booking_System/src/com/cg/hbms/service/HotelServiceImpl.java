package com.cg.hbms.service;

public class HotelServiceImpl implements HotelService{

}
